const products = [
    {
        id: "1",
        title: "Ford Mustang",
        productPageLink: "#",
        imageLink: "https://cdn.pixabay.com/photo/2012/11/02/13/02/car-63930_960_720.jpg",
        MSRP: 30000,
        purchasePrice: 25000
    },
    {
        id: "2",
        title: "Cadillac Deville",
        productPageLink: "#",
        imageLink: "https://cdn.pixabay.com/photo/2015/05/28/23/12/auto-788747_960_720.jpg",
        MSRP: 50000,
        purchasePrice: 45000
    },
    {
        id: "3",
        title: "Jeep Wrangler",
        productPageLink: "#",
        imageLink: "https://cdn.pixabay.com/photo/2023/03/15/03/46/jeep-7853620_640.jpg",
        MSRP: 53000,
        purchasePrice: 24000
    }, 
    {
        id: "4",
        title: "Audi A1",
        productPageLink: "#",
        imageLink: "https://cdn.pixabay.com/photo/2015/01/19/13/51/car-604019_640.jpg",
        MSRP: 21000,
        purchasePrice: 15000
    }
]